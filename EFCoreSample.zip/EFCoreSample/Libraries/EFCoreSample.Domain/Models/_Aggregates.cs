﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFCoreSample.Domain.Models
{
    public class _Aggregate
    {
        public Guid Id { get; set; }
        public string AggregateType { get; set; }
        public DateTime CommitDateTime { get; set; }
        public virtual ICollection<_Event> Events { get; set; }
    }
}
