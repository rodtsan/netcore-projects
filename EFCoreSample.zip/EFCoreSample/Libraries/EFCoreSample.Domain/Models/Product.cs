﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFCoreSample.Domain.Models
{
    public class Product 
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public int Order { get; set; }
        public int? UpdatedById { get; set; }
        public DateTime? UpdatedOnUtc { get; set; }
        public DateTime? CreatedOnUtc { get; set; }
        public int? CreatedById { get; set; }
        public bool Deleted { get; set; }
        public virtual ICollection<CategoryProduct> Categories { get; set; }
        public virtual ICollection<ProductImage> Images { get; set; }
        public Product() { }
    }
}
