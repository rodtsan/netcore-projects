﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace EFCoreSample.Domain.Models.Authentication
{
    public class UserClaim : IdentityUserClaim<int>
    {

    }
}