﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace EFCoreSample.Domain.Models.Authentication
{
    public class UserLogin : IdentityUserLogin<int>
    {
    }
}