﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace EFCoreSample.Domain.Models.Authentication
{
    public class User : IdentityUser<int>
    {
         public string Name { get; set; }


        //public async Task<ClaimsIdentity> GenerateUserIdentityAsync(ApplicationUserManager manager)
        //{
        //    // Note the authenticationType must match the one defined in CookieAuthenticationOptions.AuthenticationType
        //    var authenticationType = "Put authentication type Here";
        //    var claimIdentity = await manager.GetClaimsAsync(manager.get;
        //}
    }
}