﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace EFCoreSample.Domain.Models.Authentication
{
    public class RoleClaim : IdentityRoleClaim<int>
    {

    }
}