﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace EFCoreSample.Domain.Models.Authentication
{
    public class Role : IdentityRole<int>
    {
     
    }
}
