﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFCoreSample.Domain.Models
{
    public class ProductImage
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public virtual Product Product { get; set; }
        public string Name { get; set; }
        public string FileName { get; set; }
        public byte[] ImageData { get; set; }
        public string ImageType { get; set; }
        public bool IsPrimary { get; set; }
        public int Order { get; set; }
    }
}
