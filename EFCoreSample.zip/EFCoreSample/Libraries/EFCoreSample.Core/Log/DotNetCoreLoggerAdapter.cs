﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions;
using Microsoft.Extensions.Logging;

namespace EFCoreSample.Core.Log
{
    public interface ILog { void Log(LogEntry e); }

    public sealed class DotNetCoreLoggerAdapter : ILog
    {
        private readonly ILogger logger;
        public DotNetCoreLoggerAdapter(ILogger logger) { this.logger = logger; }

        public void Log(LogEntry e) =>
            logger.Log(ToLevel(e.Severity), 0, e.Message, e.Exception,
                (s, _) => s);

        private static LogLevel ToLevel(LoggingEventType s) =>
            s == LoggingEventType.Warning ? LogLevel.Warning :
            s == LoggingEventType.Error ? LogLevel.Error :
            LogLevel.Critical;
    }
}
