﻿using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using System;
using System.Security.Cryptography;

namespace EFCoreSample.Core.Common
{
    /// <summary>
    /// Class that makes login authentication compatible with ASP.NET SqlMembership.
    /// </summary>
    public class PasswordGenerator
    {
        //static readonly RNGCryptoServiceProvider Provider = new RNGCryptoServiceProvider();
        //static readonly HashAlgorithm PasswordHasher = HashAlgorithm.Create("SHA1");


        /// <summary>
        /// Creates the random password, using strong random provider
        /// </summary>
        /// <returns>strong random password</returns>
        public virtual string CreatePassword(int length)
        {
            var rng = RandomNumberGenerator.Create();
            var buffer = new byte[length];
            rng.GetBytes(buffer);
            return Convert.ToBase64String(buffer);
        }

        /// <summary>
        /// Creates the token.
        /// </summary>
        /// <returns></returns>
        public virtual string CreateToken()
        {
            return CreatePassword(32);
        }

        /// <summary>
        /// Creates the salt.
        /// </summary>
        /// <returns></returns>
        public virtual string CreateSalt()
        {
            var rng = RandomNumberGenerator.Create();
            var buffer = new byte[16];
            rng.GetBytes(buffer);
            return Convert.ToBase64String(buffer);
        }

        /// <summary>
        /// Hashes the password with the methods that are compatible with ASP.NET SqlMembership.
        /// </summary>
        /// <param name="password">The password.</param>
        /// <param name="passwordSalt">The password salt.</param>
        /// <returns>password hash that could be saved to the database.</returns>
        public virtual string HashPassword(string password, string passwordSalt)
        {
            var saltBytes = Convert.FromBase64String(passwordSalt);
            
             return Convert.ToBase64String(KeyDerivation.Pbkdf2(
             password: password,
             salt: saltBytes,
             prf: KeyDerivationPrf.HMACSHA1,
             iterationCount: 10000,
             numBytesRequested: 16));
        }


    }

}
