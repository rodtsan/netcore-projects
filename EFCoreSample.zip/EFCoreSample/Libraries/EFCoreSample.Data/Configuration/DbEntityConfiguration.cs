﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFCoreSample.Data.Configuration
{
    public abstract class DbEntityConfiguration<T> : IDbEntityConfiguration<T> where T : class
    {
        public void Map(ModelBuilder builder)
        {
            Map(builder.Entity<T>());
        }

        public abstract void Map(EntityTypeBuilder<T> entity);

    }

    public interface IDbEntityConfiguration<T> : IDbEntityConfiguration where T : class
    {
        void Map(EntityTypeBuilder<T> builder);
    }

    public interface IDbEntityConfiguration
    {
        void Map(ModelBuilder builder);
    }
}
