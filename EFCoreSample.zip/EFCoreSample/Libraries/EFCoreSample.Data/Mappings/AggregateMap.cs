﻿using EFCoreSample.Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EFCoreSample.Data.Mappings
{
    public class AggregateMap : Configuration.DbEntityConfiguration<_Aggregate>
    {
        public override void Map(EntityTypeBuilder<_Aggregate> entity)
        {
            entity.Property(p => p.Id)
                .ValueGeneratedOnAdd();
            entity.HasKey(p => p.Id);

            entity.Property(p => p.AggregateType);

            entity.Property(p => p.CommitDateTime);

            entity.HasMany(p => p.Events);

            entity.ToTable("_Aggregates");
        }
    }
}
