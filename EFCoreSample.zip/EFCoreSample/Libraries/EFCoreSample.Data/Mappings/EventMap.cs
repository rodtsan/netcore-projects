﻿using EFCoreSample.Data.Configuration;
using EFCoreSample.Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EFCoreSample.Data.Mappings
{
    public class EventMap : DbEntityConfiguration<_Event>
    {
        public override void Map(EntityTypeBuilder<_Event> entity)
        {
            entity.Property(p => p.Id)
                .ValueGeneratedOnAdd();
            entity.HasKey(p => p.Id);

            entity.Property(p => p.AggregateId);

            entity.Property(p => p.Type);
            entity.Property(p => p.Body);
            entity.Property(p => p.CommitDateTime);

            entity.HasOne(p => p.Aggregate)
                .WithMany(p => p.Events)
                .HasForeignKey(p => p.AggregateId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.ToTable("_Events");
        }
    }
}
