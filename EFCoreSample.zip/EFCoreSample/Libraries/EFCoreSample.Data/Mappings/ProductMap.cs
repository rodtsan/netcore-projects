﻿using EFCoreSample.Data.Configuration;
using EFCoreSample.Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EFCoreSample.Data.Mapping
{
    public class ProductMap : DbEntityConfiguration<Product>
    {
        public override void Map(EntityTypeBuilder<Product> entity)
        {
            entity.ToTable("Products");
            entity.Property(p => p.Id).ValueGeneratedOnAdd();
            entity.HasKey(p => p.Id);

            entity.Property(p => p.Name).HasMaxLength(255).IsRequired();
            entity.Property(p => p.Description)
                .HasMaxLength(2000)
                .IsRequired();
            entity.Property(p => p.Price);
            entity.Property(p => p.UpdatedById);
            entity.Property(p => p.UpdatedOnUtc);
            entity.Property(p => p.Order);

            entity.HasMany(p => p.Images);

        }
    }
}
