﻿
using EFCoreSample.Data.Configuration;
using EFCoreSample.Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EFCoreSample.Data.Mapping
{
    public class CategoryMap : DbEntityConfiguration<Category>
    {
        public override void Map(EntityTypeBuilder<Category> entity)
        {
            entity.ToTable("Categories");
            entity.Property(p => p.Id).ValueGeneratedOnAdd();
            entity.HasKey(p => p.Id);
   
            entity.Property(p => p.Name).HasMaxLength(255).IsRequired();
            entity.Property(p => p.Description).HasMaxLength(2000);
            entity.Property(p => p.Order);
            
            entity.Property(p => p.UpdatedById);
            entity.Property(p => p.UpdatedOnUtc);
            entity.Property(p => p.ParentId);
   
            entity.HasOne(p => p.Parent)
                .WithMany(p => p.Categories)
                .HasForeignKey(p => p.ParentId);

            entity.HasMany(p => p.Categories)
                .WithOne(p => p.Parent)
                .HasForeignKey(p => p.ParentId);
           
        }
    }
}
