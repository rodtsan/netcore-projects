﻿using EFCoreSample.Data.Configuration;
using EFCoreSample.Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EFCoreSample.Data.Mappings
{
    public class ProductImageMap : DbEntityConfiguration<ProductImage>
    {
        public override void Map(EntityTypeBuilder<ProductImage> entity)
        {
            entity.ToTable("ProductImages");
            entity.Property(p => p.Id).ValueGeneratedOnAdd();
            entity.HasKey(p => p.Id);

            entity.Property(p => p.FileName).HasMaxLength(255).IsRequired();
            entity.Property(p => p.Name).HasMaxLength(255).IsRequired();
            entity.Property(p => p.ImageData);
            entity.Property(p => p.ImageType).HasMaxLength(25);
            entity.Property(p => p.IsPrimary);
            entity.Property(p => p.Order);

            entity.HasOne(p => p.Product)
                .WithMany(p => p.Images)
                .HasForeignKey(p => p.ProductId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
