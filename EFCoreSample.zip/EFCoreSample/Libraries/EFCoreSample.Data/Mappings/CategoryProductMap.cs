﻿using EFCoreSample.Data.Configuration;
using EFCoreSample.Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EFCoreSample.Data.Mapping
{
    public class CategoryProductMap : DbEntityConfiguration<CategoryProduct>
    {
        public override void Map(EntityTypeBuilder<CategoryProduct> entity)
        {
            entity.Property(p => p.CategoryId);

            entity.Property(p => p.ProductId);
          
            entity.HasKey(p => new { p.CategoryId, p.ProductId});

            entity.HasOne(p => p.Category)
                    .WithMany(p => p.Products)
                    .HasForeignKey(p => p.CategoryId)
                    .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(p => p.Product)
                .WithMany(p => p.Categories)
                .HasForeignKey(p => p.ProductId)
                .OnDelete(DeleteBehavior.Cascade);

            entity.ToTable("CategoriesProductsMapping");
        }
    }
}
