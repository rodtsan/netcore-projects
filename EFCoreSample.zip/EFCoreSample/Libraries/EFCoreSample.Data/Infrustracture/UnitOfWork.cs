﻿using EFCoreSample.Data.Infrustracture;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCoreSample.Data.Infrastructure
{
    /// <summary>
    /// 
    /// </summary>
    public class UnitOfWork : IUnitOfWork
    {
        private readonly IDbContext context;
        public UnitOfWork(IDbContext context)
        {
            this.context = context;
        }

        public int Commit()
        {
            return this.context.Commit();
        }

        public async Task<int> CommitAsync()
        {
            return await Task<int>.Run(() =>
             {
                 return this.context.Commit();
             });
        }
    }
}
