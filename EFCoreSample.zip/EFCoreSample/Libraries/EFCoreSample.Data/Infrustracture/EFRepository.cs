﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace EFCoreSample.Data.Infrustracture
{

    public class EFRepository<T> : IEFRepository<T> where T : class, new()
    {
        private readonly IDbContext _content;
        public EFRepository(IDbContext content)
        {
            this._content = content;
        }

        public virtual T GetById(object Id)
        {
            //see some suggested performance optimization (not tested)
            //http://stackoverflow.com/questions/11686225/dbset-find-method-ridiculously-slow-compared-to-singleordefault-on-id/11688189#comment34876113_11688189
            return this.Entities.Find(Id);
        }

        public async Task<T> GetByIdAsync(object Id)
        {
            //see some suggested performance optimization (not tested)
            //http://stackoverflow.com/questions/11686225/dbset-find-method-ridiculously-slow-compared-to-singleordefault-on-id/11688189#comment34876113_11688189
            return await this.Entities.FindAsync(Id);
        }

        public virtual void Add(T entity)
        {
            if (entity == null)
                throw new ArgumentNullException("entity");

            this.Entities.Add(entity);
        }

        public async Task AddAsync(T entity)
        {
            if (entity == null)
                throw new ArgumentNullException("entity");

            await this.Entities.AddAsync(entity);
        }

        public virtual void Update(T entity)
        {
            this.Entities.Update(entity);
        }

        public async Task UpdateAsync(T entity)
        {
            await Task.Run(() =>
            {
                this.Entities.Update(entity);
            });

        }

        public virtual void Delete(T entity)
        {
            this.Entities.Remove(entity);
        }

        public async Task DeleteAsync(T entity)
        {
            await Task.Run(() =>
            {
                this.Entities.Remove(entity);
            });

        }

        public virtual IQueryable<T> Table
        {
            get
            {
                return this.Entities.AsQueryable();
            }
        }

        public virtual IQueryable<T> TableNoTracking
        {
            get
            {
                return this.Entities.AsQueryable();
            }
        }

        protected virtual DbSet<T> Entities
        {
            get
            {
                return this._content.Entities<T>();
            }
        }

        protected int Commit()
        {
            try
            {
                return this._content.Commit();
            }
            catch (DbUpdateConcurrencyException dbEx)
            {
                throw new Exception("Database Concurrency error while trying to save changes: ", dbEx);
            }
            catch (DbUpdateException dbEx)
            {
                throw new Exception("Database error while trying to save changes: ", dbEx);
            }
            catch (Exception dbEx)
            {
                throw new Exception("Database general error while trying to save changes: ", dbEx);
            }
        }

        protected async Task<int> CommitAsync()
        {
            return await Task<int>.Run(() =>
            {
                try
                {
                    return this._content.CommitAsync();
                }
                catch (DbUpdateConcurrencyException dbEx)
                {
                    throw new Exception("Database Concurrency error while trying to save changes: ", dbEx);
                }
                catch (DbUpdateException dbEx)
                {
                    throw new Exception("Database error while trying to save changes: ", dbEx);
                }
                catch (Exception dbEx)
                {
                    throw new Exception("Database general error while trying to save changes: ", dbEx);
                }
            });

        }

       

        #region IDisposable Support

        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~EFRepository() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }

        #endregion
    }
}