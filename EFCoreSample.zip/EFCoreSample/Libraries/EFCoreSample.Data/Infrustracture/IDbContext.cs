﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EFCoreSample.Data.Infrustracture
{
    public interface IDbContext : IDisposable
    {
        DbSet<T> Entities<T>() where T : class;
        int Commit();
        Task<int> CommitAsync();     

    }

}
