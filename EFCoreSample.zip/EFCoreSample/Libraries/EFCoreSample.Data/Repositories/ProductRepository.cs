﻿using EFCoreSample.Data.Infrustracture;
using EFCoreSample.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFCoreSample.Data.Repositories
{
    public class ProductRepository : EFRepository<Product>, IProductRepository
    {
        public ProductRepository(IDbContext context)
            : base(context)
        {

        }
    }

    internal interface IProductRepository
    {
    }
}
