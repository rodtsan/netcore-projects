﻿using EFCoreSample.Data.Infrustracture;
using EFCoreSample.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFCoreSample.Data.Repositories
{
    public class CategoryRepository : EFRepository<Category>, ICategoryRepository
    {
        public CategoryRepository(IDbContext context)
            : base(context)
        {
                
        }
    }

    internal interface ICategoryRepository
    {
    }
}
