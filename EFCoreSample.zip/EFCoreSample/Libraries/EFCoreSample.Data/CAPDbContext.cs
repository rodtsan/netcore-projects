﻿using System;
using System.Threading.Tasks;
using EFCoreSample.Data.Infrustracture;
using EFCoreSample.Data.Mapping;
using EFCoreSample.Domain.Models.Authentication;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace EFCoreSample.Data
{
    public class CAPDbContext : IdentityDbContext<User, Role, int>, IDbContext
    {

        public CAPDbContext(DbContextOptions<CAPDbContext> options)
            : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
           

            builder.AddFromAssembly<CategoryMap>();

            base.OnModelCreating(builder);
            // Customize the ASP.NET Identity model and override the defaults if needed.
            // For example, you can rename the ASP.NET Identity table names and more.
            // Add your customizations after calling base.OnModelCreating(builder);
           
            foreach (var model in builder.Model.GetEntityTypes()
               .Where(p => p.Relational().TableName.StartsWith(@"AspNet")))
            {
                string tableName = model.Relational().TableName.Remove(0, @"AspNet".Length);
                model.Relational().TableName = tableName;
            }
        }

        public int Commit()
        {
            return this.SaveChanges();
        }

        public async Task<int> CommitAsync()
        {
            return await this.SaveChangesAsync();
        }

        public DbSet<T> Entities<T>() where T : class
        {
            return this.Set<T>();
        }
    }

}
