﻿using EFCoreSample.Domain.Models.Authentication;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace EFCoreSample.Data.Authentication
{
    public class ApplicationUserStore : UserStore<User, Role, CAPDbContext, int>
    {
        public ApplicationUserStore(CAPDbContext context, IdentityErrorDescriber describer = null) : base(context, describer)
        {

        }
    }
}
