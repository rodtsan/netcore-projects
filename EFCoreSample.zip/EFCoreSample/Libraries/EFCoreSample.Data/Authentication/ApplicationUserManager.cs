﻿using EFCoreSample.Domain.Models.Authentication;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EFCoreSample.Data.Authentication
{
    public class ApplicationUserManager : UserManager<UserToken>
    {
        public ApplicationUserManager(IUserStore<UserToken> store, IOptions<IdentityOptions> optionsAccessor, IPasswordHasher<UserToken> passwordHasher, IEnumerable<IUserValidator<UserToken>> userValidators, IEnumerable<IPasswordValidator<UserToken>> passwordValidators, ILookupNormalizer keyNormalizer, IdentityErrorDescriber errors, IServiceProvider services, ILogger<UserManager<UserToken>> logger) 
            : base(store, optionsAccessor, passwordHasher, userValidators, passwordValidators, keyNormalizer, errors, services, logger)
          
        {
        }
       
        public async Task<UserToken> FindByNameOrEmailAsync
            (string usernameOrEmail)
        {
            var username = usernameOrEmail;
            if (usernameOrEmail.Contains("@"))
            {
                var userForEmail = await this.FindByEmailAsync(usernameOrEmail);
                if (userForEmail != null)
                {
                    username = userForEmail.Name;
                }
            }
            return await FindByNameAsync(username);
        }

    }
   
}
