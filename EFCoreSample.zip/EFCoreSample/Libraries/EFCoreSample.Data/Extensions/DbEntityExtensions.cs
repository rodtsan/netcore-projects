﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Microsoft.EntityFrameworkCore
{
    public static class DbEntityExtensions
    {
        public static void AddOrUpdate<T>(this DbSet<T> db, T entity) where T : class
        {
            var entry = db.Attach(entity);
            switch (entry.State)
            {
                case EntityState.Detached:
                    db.Add(entity);
                    break;
                case EntityState.Modified:
                    db.Update(entity);
                    break;
                case EntityState.Added:
                    db.Add(entity);
                    break;
                case EntityState.Unchanged:
                    //item already in db no need to do anything
                    break;

                default:
                    throw new ArgumentOutOfRangeException();
            }
        }

    }

}
