﻿using System;
using Microsoft.EntityFrameworkCore;
using EFCoreSample.Data.Authentication;
using EFCoreSample.Domain.Models.Authentication;
using System.Threading.Tasks;

namespace EFCoreSample.Data
{
    public static class DbContextExtensions
    {
        // Database Migrations
        public static void Seed(this CAPDbContext context)
        {
            // Perform database delete and create
            context.Database.EnsureDeleted();
            bool _isEnsureCreated = false;
            if (!_isEnsureCreated)
            {
                //context.Database.EnsureDeleted();
                context.Database.EnsureCreated();

                if (!Task<bool>.Run(() =>
                {
                    return context.Roles.AnyAsync();
                }).Result)
                {
                    context.Roles.Add(new Role
                    {
                        Name = "Administrator",
                        NormalizedName = "admin",
                        ConcurrencyStamp = DateTime.Now.ToString(),
                    });

                    context.SaveChanges();
                }
            }
        }
    }
}
