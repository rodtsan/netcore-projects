﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Reflection;
using EFCoreSample.Data.Mapping;
using EFCoreSample.Data.Configuration;

namespace EFCoreSample.Data
{

    internal static class ModelBuilderExtensions
    {
        private static IEnumerable<Type> GetMappingTypes(this Assembly assembly, Type mappingInterface)
        {
            return assembly.GetTypes().Where(x => !x.GetTypeInfo().IsAbstract && x.GetInterfaces().Any(y => y.GetTypeInfo().IsGenericType && y.GetGenericTypeDefinition() == mappingInterface));
        }

        public static void AddFromAssembly<T>(this ModelBuilder builder) where T : class
        {
            var mappingTypes = typeof(T).GetTypeInfo().Assembly.GetMappingTypes(typeof(IDbEntityConfiguration<>));
            foreach (var config in mappingTypes.Select(Activator.CreateInstance).Cast<IDbEntityConfiguration>())
            {
                config.Map(builder);
            }
        }

    }
}
