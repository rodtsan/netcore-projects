﻿using EFCoreSample.Cafe.Tab;
using EFCoreSample.WebCafe.ActionFilters;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace EFCoreSample.WebCafe.Controllers
{
    [IncludeLayoutData]
    public class ChefController : Controller
    {
        public IActionResult Index()
        {
            return View(Domain.ChefTodoListQueries.GetTodoList());
        }

        public IActionResult MarkPrepared(Guid id, IFormCollection form)
        {
            Domain.Dispatcher.SendCommand(new MarkFoodPrepared
            {
                Id = id,
                MenuNumbers = (from entry in form.Keys.Cast<string>()
                               where form[entry] != "false"
                               let m = Regex.Match(entry, @"prepared_\d+_(\d+)")
                               where m.Success
                               select int.Parse(m.Groups[1].Value)
                              ).ToList()
            });

            return RedirectToAction("Index");
        }
    }
}
