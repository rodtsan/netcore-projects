﻿using EFCoreSample.WebCafe.ActionFilters;
using Microsoft.AspNetCore.Mvc;

namespace EFCoreSample.WebCafe.Controllers
{
    [IncludeLayoutData]
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }


      
    }
}
