﻿using EFCoreSample.Cafe.Events;
using EFCoreSample.Cafe.Tab;
using EFCoreSample.WebCafe.ActionFilters;
using EFCoreSample.WebCafe.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace EFCoreSample.WebCafe.Controllers
{
    [IncludeLayoutData]
    public class TabController : Controller
    {
        public IActionResult Open()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Open(OpenTab cmd)   
        {
            cmd.Id = Guid.NewGuid();
            Domain.Dispatcher.SendCommand(cmd);
            return RedirectToAction("Order", new { id = cmd.TableNumber });
        }
        
        public IActionResult Close(int id) {
            return View(new CloseModel 
            {
                Id = id
            });
        }

        [HttpPost]
        public IActionResult Close(CloseModel model) {
            Domain.Dispatcher.SendCommand(new CloseTab {
                 Id = Domain.OpenTabQueries.TabIdForTable(model.Id),
                 AmountPaid = model.AmountPaid
            });
            return RedirectToAction("Index", "Home");
        }

        public IActionResult Status(int id)
        {
            return View(Domain.OpenTabQueries.TabForTable(id));
        }

        public IActionResult Order(int id)
        {
            return View(new OrderModel
            {
                Items = (from item in StaticData.Menu
                         select new OrderModel.OrderItem
                         {
                             MenuNumber = item.MenuNumber,
                             Description = item.Description,
                             NumberToOrder = 0
                         }).ToList(),
            });
        }

        [HttpPost]
        public IActionResult Order(int id, OrderModel order)
        {
            var items = new List<OrderedItem>();
            var menuLookup = StaticData.Menu.ToDictionary(k => k.MenuNumber, v => v);
            foreach (var item in order.Items)
                for (int i = 0; i < item.NumberToOrder; i++)
                    items.Add(new OrderedItem
                    {
                        MenuNumber = item.MenuNumber,
                        Description = menuLookup[item.MenuNumber].Description,
                        Price = menuLookup[item.MenuNumber].Price,
                        IsDrink = menuLookup[item.MenuNumber].IsDrink
                    });
            
            Domain.Dispatcher.SendCommand(new PlaceOrder
            {
                Id = Domain.OpenTabQueries.TabIdForTable(id),
                Items = items
            });

            return RedirectToAction("Status", new { id = id });
        }


        public IActionResult MarkServed(int id, IFormCollection form)
        {
            var tabId = Domain.OpenTabQueries.TabIdForTable(id);
            var menuNumbers = (from entry in form.Keys.Cast<string>()
                               where form[entry] != "false"
                               let m = Regex.Match(entry, @"served_\d+_(\d+)")
                               where m.Success
                               select int.Parse(m.Groups[1].Value)
                              ).ToList();

            var menuLookup = StaticData.Menu.ToDictionary(k => k.MenuNumber, v => v);
            
            var drinks = menuNumbers.Where(n => menuLookup[n].IsDrink).ToList();
            if (drinks.Any())
                Domain.Dispatcher.SendCommand(new MarkDrinksServed
                {
                    Id = tabId,
                    MenuNumbers = drinks
                });

            var food = menuNumbers.Where(n => !menuLookup[n].IsDrink).ToList();
            if (food.Any())
                Domain.Dispatcher.SendCommand(new MarkFoodServed
                {
                    Id = tabId,
                    MenuNumbers = food
                });

            return RedirectToAction("Status", new { id = id });
        }

    }
}
