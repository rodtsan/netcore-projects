﻿using EFCoreSample.WebCafe.ActionFilters;
using Microsoft.AspNetCore.Mvc;

namespace EFCoreSample.WebCafe.Controllers
{
    [IncludeLayoutData]
    public class WaitStaffController : Controller
    {
        public IActionResult Todo(string id)
        {
            ViewBag.Waiter = id;
            return View(Domain.OpenTabQueries.TodoListForWaiter(id));
        }
    }
}
