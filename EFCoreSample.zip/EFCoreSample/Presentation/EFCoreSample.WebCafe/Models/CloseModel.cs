﻿namespace EFCoreSample.WebCafe.Models
{
    public class CloseModel
    {
        public int Id { get; set; }
        public decimal AmountPaid { get; set; }
    }
}