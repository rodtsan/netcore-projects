﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EFCoreSample.Cafe.Events
{
    public class FoodServed
    {
        public Guid Id;
        public List<int> MenuNumbers;
    }
}
