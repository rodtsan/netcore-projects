﻿using System;
using System.Collections.Generic;

namespace EFCoreSample.Cafe.Models
{
    public interface IChefTodoListQueries
    {
        List<ChefTodoList.TodoListGroup> GetTodoList();
    }
}
