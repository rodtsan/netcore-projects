﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EFCoreSample.Cafe.Tab
{
    public class MarkFoodServed
    {
        public Guid Id;
        public List<int> MenuNumbers;
    }
}
