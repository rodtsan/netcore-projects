﻿using EFCoreSample.Cafe.Events;
using System;
using System.Collections.Generic;

namespace EFCoreSample.Cafe.Tab
{
    public class PlaceOrder
    {
        public Guid Id;
        public List<OrderedItem> Items;
    }
}
