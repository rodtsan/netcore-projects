﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EFCoreSample.Cafe.Tab
{
    public class TabNotOpen : Exception
    {
        public override string Message
        {
            get
            {
                return "Tab not open";
            }
        }
    }

    public class DrinksNotOutstanding : Exception
    {
        public override string Message
        {
            get
            {
                return "Drink not outstanding";
            }
        }
    }

    public class FoodNotOutstanding : Exception
    {
        public override string Message
        {
            get
            {
                return "Food not outstanding";
            }
        }
    }

    public class FoodNotPrepared : Exception
    {
        public override string Message
        {
            get
            {
                return "Food not prepared";
            }
        }
    }

    public class MustPayEnough : Exception
    {
        public override string Message
        {
            get
            {
                return "Pay isn't enough";
            }
        }
    }

    public class TabHasUnservedItems : Exception
    {
        public override string Message
        {
            get
            {
                return "You have an unserved items";
            }
        }
    }
}
