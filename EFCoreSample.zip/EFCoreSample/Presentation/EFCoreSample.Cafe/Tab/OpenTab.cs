﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EFCoreSample.Cafe.Tab
{
    public class OpenTab
    {
        public Guid Id;
        public int TableNumber { get; set; }
        public string Waiter { get; set; }
    }
}
